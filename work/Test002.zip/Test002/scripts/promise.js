
var global = 0;


angular.module('myApp', [])
  .controller('MyController', ['$scope', '$timeout', '$log', '$q', function($scope, $timeout, $log, $q) {

	$scope.test = 10;

	var getYYYYMMDDhhmmssfff = function (){
		var dt = new Date();
		var YYYY = dt.getFullYear();
		var MM = dt.getMonth()+1;
		var DD = dt.getDate();
		var hh = dt.getHours();
		var mm = dt.getMinutes();
		var ss = dt.getSeconds();
		var ms = dt.getMilliseconds();
		return YYYY + '/' + MM + '/' + DD + ' ' + hh + ':' + mm + ':' + ss + '.' + ms;
	};

    var writeLog = function(str){
		$log.log( getYYYYMMDDhhmmssfff() + ':' + str );
	};

    var asyncHello = function(name) {
      var deferred = $q.defer();

      writeLog(name);

      $timeout(function() {
        var msg = '5秒経ったみたいです' + ':' + global + ':' + $scope.test;
        alert(msg);
        writeLog(msg);
        
        global++;
		$scope.test++;
        
        deferred.resolve('Hello, ' + name);
        
      }, 5000);

      writeLog('asyncHello return');

      return deferred.promise;
    };

    writeLog('asyncHello before call');

    var promise = asyncHello('promise part1');

    writeLog('asyncHello after call');

    promise.then(function(msg) {				// thenはPromiseが解決するまでブロックしない
												// なので、次の処理（asyncHello('promise part2');）にすぐ進む
      writeLog(msg);							// 5秒後にPromiseが解決されたら、thenが動き出す

      writeLog('then1');

      $timeout(function() {
        var msg = '5秒経ったみたいです part2';
        alert(msg);
        writeLog(msg);

      }, 5000);

      return 'then1 resolve result';
    }).then(function(msg){
		writeLog(msg);

        writeLog('then2');
    });
    
    
    asyncHello('promise part2');
    
    
  }]);

/* 出力結果

2019/7/18 20:38:2.617:asyncHello before call
2019/7/18 20:38:2.626:promise part1
2019/7/18 20:38:2.628:asyncHello return
2019/7/18 20:38:2.630:asyncHello after call
2019/7/18 20:38:2.633:promise part2
2019/7/18 20:38:2.634:asyncHello return
2019/7/18 20:38:8.265:5秒経ったみたいです:0:10
2019/7/18 20:38:8.268:Hello, promise part1
2019/7/18 20:38:8.274:then1
2019/7/18 20:38:8.275:then1 resolve result
2019/7/18 20:38:8.277:then2
2019/7/18 20:38:8.890:5秒経ったみたいです:1:11
2019/7/18 20:38:15.770:5秒経ったみたいです part2

*/



moge
fuga
